#include <stdio.h>
#include <conio.h>
struct student{
	char Name[40];
	int clas;
	struct dob{
		int Date;
		int Month;
		int Year;
	};
};
int main(){
	struct student a ;
	struct dob b;
	printf("Enter your name");
	scanf("%s",&a.Name);
	printf("Enter your class name");
	scanf("%d",&a.clas);
	scanf("%d %d %d",&b.Date,&b.Month,&b.Year);
	
	printf("%s",a.Name);
	printf("%d",a.clas);
   	printf("%d %d %d",b.Date,b.Month,b.Year);
   	
	return 0;
}
