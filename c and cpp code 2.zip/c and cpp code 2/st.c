#include<stdio.h>
#define  skk struct
skk hi{
	int  i;	
	/*c language struct uses table input tutorial*/	
	/*thanks for watching*/	
};
int main(){
	int t;
	printf("type your table \n ");
	struct hi jk;
	scanf("%d",&jk.i);
	for(t=1;t<=10;t++){
		int ap = jk.i*t;
		printf("%d \n",ap);
	}
}
