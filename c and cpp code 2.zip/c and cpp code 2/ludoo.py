import cv2
import numpy as np

ASCII_CHARS = "@%#*+=-:. "

WIDTH = 120


def frame_to_ascii(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    h, w = gray.shape

    aspect_ratio = h / w

    new_height = int(aspect_ratio * WIDTH * 0.55)

    resized = cv2.resize(gray, (WIDTH, new_height))

    ascii_image = ""

    for row in resized:
        for pixel in row:
            index = int(pixel / 255 * (len(ASCII_CHARS) - 1))
            ascii_image += ASCII_CHARS[index]
        ascii_image += "\n"

    return ascii_image


video = input("Enter video path: ")

cap = cv2.VideoCapture(video)

if not cap.isOpened():
    print("Cannot open video.")
    exit()

fps = cap.get(cv2.CAP_PROP_FPS)

delay = int(1000 / fps)

while True:

    ret, frame = cap.read()

    if not ret:
        break

    ascii_frame = frame_to_ascii(frame)

    print("\033[H\033[J", end="")     # Clear terminal

    print(ascii_frame)

    if cv2.waitKey(delay) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()