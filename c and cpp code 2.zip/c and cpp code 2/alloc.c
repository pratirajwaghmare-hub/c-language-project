#include <stdio.h>
#include <stdlib.h>
/* c language alloction memmory free tutorial*/
int main() {
    int *ptr = (int *)malloc(sizeof(int));

    *ptr = 100;
    printf("%d\n", *ptr);

    free(ptr);
    ptr = NULL;

    return 0;
}
