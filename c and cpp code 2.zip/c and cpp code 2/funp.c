#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
    #include <windows.h>
    #include <conio.h>
    
    // Fix for older Windows/Dev-C++ headers missing the ANSI flag definition
    #ifndef ENABLE_VIRTUAL_TERMINAL_PROCESSING
        #define ENABLE_VIRTUAL_TERMINAL_PROCESSING 0x0004
    #endif
#else
    #include <unistd.h>
#endif

// --- Color Codes (ANSI Escape Sequences) ---
#define COLOR_RESET   "\x1b[0m"
#define COLOR_BLUE    "\x1b[34m"
#define COLOR_GREEN   "\x1b[32m"
#define COLOR_CYAN    "\x1b[36m"
#define COLOR_RED     "\x1b[31m"
#define COLOR_YELLOW  "\x1b[33m"
#define COLOR_WHITE   "\x1b[37m"
#define BG_BLUE       "\x1b[44m"
#define BG_DARK_GRAY  "\x1b[100m"

// --- Constants ---
#define MENU_OPTIONS 8

// --- Global Variables ---
int current_selection = 0;
const char *menu_items[MENU_OPTIONS] = {
    "1. New File",
    "2. Open File",
    "3. Save File",
    "4. Compile",
    "5. Run",
    "6. Settings",
    "7. Help",
    "8. Exit"
};

// --- Function Declarations ---
void clearScreen();
void displayTitleBar();
void displayStatusBar(const char *message);
void displayWelcomePage();
void displayMenu();
void handlePage(int choice);
void getCurrentDateTime(char *buffer, int size);

// Dummy pages for environment options
void pageNewFile();
void pageOpenFile();
void pageSaveFile();
void pageCompile();
void pageRun();
void pageSettings();
void pageHelp();

int main() {
    char input = ' ';
    
    // Enable ANSI support on older Windows consoles if necessary
    #ifdef _WIN32
        HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
        DWORD dwMode = 0;
        GetConsoleMode(hOut, &dwMode);
        SetConsoleMode(hOut, dwMode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
    #endif

    displayWelcomePage();
    
    while (1) {
        clearScreen();
        displayTitleBar();
        displayMenu();
        displayStatusBar("Use 'W' (Up), 'S' (Down), and 'Enter' to navigate. Or press 1-8.");

        // Input handling
        #ifdef _WIN32
            input = getch();
            if (input == 'w' || input == 'W') {
                current_selection = (current_selection - 1 + MENU_OPTIONS) % MENU_OPTIONS;
            } else if (input == 's' || input == 'S') {
                current_selection = (current_selection + 1) % MENU_OPTIONS;
            } else if (input == 13) { // Enter key
                if (current_selection == 7) break; // Exit
                handlePage(current_selection + 1);
            } else if (input >= '1' && input <= '8') {
                int choice = input - '0';
                if (choice == 8) break;
                handlePage(choice);
            }
        #else
            // Fallback for standard input if non-Windows terminal
            printf("\n" COLOR_CYAN " Enter choice (1-8) or W/S to move: " COLOR_RESET);
            int scanInput = getchar();
            while (getchar() != '\n'); 
            
            if (scanInput == 'w' || scanInput == 'W') {
                current_selection = (current_selection - 1 + MENU_OPTIONS) % MENU_OPTIONS;
            } else if (scanInput == 's' || scanInput == 'S') {
                current_selection = (current_selection + 1) % MENU_OPTIONS;
            } else if (scanInput >= '1' && scanInput <= '8') {
                int choice = scanInput - '0';
                if (choice == 8) break;
                handlePage(choice);
            } else if (scanInput == '\n' || scanInput == ' ') {
                handlePage(current_selection + 1);
            }
        #endif
    }

    clearScreen();
    printf(COLOR_GREEN "\n Thank you for using C Programming Workspace! Goodbye.\n\n" COLOR_RESET);
    return 0;
}

// --- Helper Functions ---

void clearScreen() {
    printf("\x1b[H\x1b[J");
}

void getCurrentDateTime(char *buffer, int size) {
    time_t rawtime;
    struct tm *timeinfo;
    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(buffer, size, "%Y-%m-%d %H:%M:%S", timeinfo);
}

// --- UI Layout Sections ---

void displayTitleBar() {
    printf(BG_BLUE COLOR_WHITE " ============================================================================ " COLOR_RESET "\n");
    printf(BG_BLUE COLOR_WHITE "                      C PROGRAMMING WORKSPACE v1.0.0                          " COLOR_RESET "\n");
    printf(BG_BLUE COLOR_WHITE " ============================================================================ " COLOR_RESET "\n\n");
}

void displayStatusBar(const char *message) {
    char dateTime[30];
    getCurrentDateTime(dateTime, sizeof(dateTime));
    
    printf("\n");
    printf(BG_DARK_GRAY COLOR_WHITE " %-48s | %s " COLOR_RESET "\n", message, dateTime);
}

void displayWelcomePage() {
    clearScreen();
    printf(COLOR_CYAN);
    printf(" +--------------------------------------------------------------------------+ \n");
    printf(" �                                                                          � \n");
    printf(" �          " COLOR_YELLOW "WELCOME TO THE C PROGRAMMING WORKSPACE APPLICATION" COLOR_CYAN "              � \n");
    printf(" �                                                                          � \n");
    printf(" �   A lightweight, console-driven environment designed for clean coders    � \n");
    printf(" �                                                                          � \n");
    printf(" �   Features:                                                              � \n");
    printf(" �   * Workspace file control        * On-the-fly execution structure       � \n");
    printf(" �   * ASCII interface styling       * Keyboard native navigation           � \n");
    printf(" �                                                                          � \n");
    printf(" +--------------------------------------------------------------------------+ \n");
    printf(COLOR_RESET);
    printf("\n " COLOR_GREEN "Press [ENTER] to launch the workspace workspace..." COLOR_RESET);
    getchar();
}

void displayMenu() {
    int i; 
    printf(" " COLOR_CYAN "+--------------------- WORKSPACE MAIN MENU ---------------------+" COLOR_RESET "\n");
    
    for (i = 0; i < MENU_OPTIONS; i++) {
        if (i == current_selection) {
            printf(" " COLOR_CYAN "�" COLOR_RESET "  " BG_BLUE COLOR_WHITE " %-56s " COLOR_RESET " " COLOR_CYAN "�" COLOR_RESET "\n", menu_items[i]);
        } else {
            printf(" " COLOR_CYAN "�" COLOR_RESET "   %-56s  " COLOR_CYAN "�" COLOR_RESET "\n", menu_items[i]);
        }
    }
    
    printf(" " COLOR_CYAN "+---------------------------------------------------------------+" COLOR_RESET "\n");
}

// --- Page Router ---

void handlePage(int choice) {
    clearScreen();
    displayTitleBar();
    
    switch (choice) {
        case 1: pageNewFile(); break;
        case 2: pageOpenFile(); break;
        case 3: pageSaveFile(); break;
        case 4: pageCompile(); break;
        case 5: pageRun(); break;
        case 6: pageSettings(); break;
        case 7: pageHelp(); break;
        default: break;
    }
    
    displayStatusBar("Returning back to workspace dashboard...");
    printf("\n Press [ENTER] to return to Main Menu...");
    #ifdef _WIN32
        getch();
    #else
        getchar();
    #endif
}

// --- Individual Workspace Pages ---

void pageNewFile() {
    printf(COLOR_YELLOW " [1. NEW FILE] " COLOR_RESET "\n\n");
    printf(" Creating a template workspace document inside memory buffers...\n");
    printf(" " COLOR_GREEN "?" COLOR_RESET " Target main.c initialized successfully.\n");
    printf(" Default headers `#include <stdio.h>` added to workspace code field.\n");
}

void pageOpenFile() {
    printf(COLOR_YELLOW " [2. OPEN FILE] " COLOR_RESET "\n\n");
    printf(" Scanning project tree layout directory...\n");
    printf("   -> src/main.c\n");
    printf("   -> src/utils.h\n\n");
    printf(" " COLOR_GREEN "?" COLOR_RESET " Loaded source file: src/main.c (42 lines buffer size).\n");
}

void pageSaveFile() {
    printf(COLOR_YELLOW " [3. SAVE FILE] " COLOR_RESET "\n\n");
    printf(" Syncing volatile text buffer blocks with storage filesystem hardware...\n");
    printf(" " COLOR_GREEN "?" COLOR_RESET " Changes flushed cleanly to disk. 0 bytes mismatched.\n");
}

void pageCompile() {
    printf(COLOR_YELLOW " [4. COMPILE WORKSPACE] " COLOR_RESET "\n\n");
    printf(" Launching standard toolchain engine call: `gcc main.c -o app.out` ...\n");
    printf(" Analyzing code definitions and standard template declarations...\n");
    printf(COLOR_GREEN " Compilation Phase Ended: 0 Errors, 0 Warnings.\n" COLOR_RESET);
}

void pageRun() {
    printf(COLOR_YELLOW " [5. RUN EXECUTABLE] " COLOR_RESET "\n\n");
    printf(" Executing operational binary child instance...\n");
    printf(" ----------------------------------------------------------------\n");
    printf(COLOR_WHITE " Hello, World! This output is running inside your IDE.\n" COLOR_RESET);
    printf(" ----------------------------------------------------------------\n\n");
    printf(" " COLOR_GREEN "?" COLOR_RESET " Executed task closed with termination status return: 0\n");
}

void pageSettings() {
    printf(COLOR_YELLOW " [6. ENV SETTINGS] " COLOR_RESET "\n\n");
    printf(" Current active environment profiles:\n");
    printf("  - Active Compiler: GCC Toolchain distribution\n");
    printf("  - Document Encoding: UTF-8 standard text layout\n");
    printf("  - Editor Auto-Save: Enabled (5 Minute intervals)\n");
    printf("  - Tab Size Style: 4 Spaces format conversion\n");
}

void pageHelp() {
    printf(COLOR_YELLOW " [7. HELP & SHORTCUT DETAILS] " COLOR_RESET "\n\n");
    printf(" Welcome to the minimalist terminal workspace manual documentation.\n\n");
    printf(" Key Layout mapping rules:\n");
    printf("  - 'W' / 's' : Move focus item selectors sequentially.\n");
    printf("  - Num [1-8] : Direct switch context index execution instantly.\n");
    printf("  - Enter     : Run highlighted module process tree.\n");
}
