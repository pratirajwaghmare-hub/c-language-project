#include<iostream>
using namespace std;
/* cpp nested mixed loop tutorial*/
 int main(){
   int i,j,k;
   while(i<=10){
   	i++;
   	cout<<i<<"while\n";
   	 do{
   	 	j++;
   	 	cout<<j<<"dowhile\n";
   	 	for(k=1;k<=10;k++){
   	 	cout<<k<<"forloop\n";
			}
				
		}while(j<=10);
   }
}
