#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main(){
	int f = 0;
	int i;
	int j;
	while(1){
		printf("\033[H\033[1;34m [DEEP-SPACE RECEIVER]\n");
		for(i=0;i<18; i++){
			printf(" %04X: ", rand()%0xFFFF);
			for(j=0;j<35;j++){
				if(j == f) printf("\033[1;31m#");
				else if(rand() % 25 == 0) printf("\033[0;34m|");
				else printf("\033[0;30m.");
			}
			printf("\033[0m\n");
		}
		f = (f - 1) % 35;
		if(f > 15 && f < 20)
		   printf("\n \033[1;32m>>> SIGNAL LOCK: 1420MHZ  <<<\n");
		   else  printf("\n SCANNING FOR UPLINK...\n");
		   usleep(90000);
	}
	return 0;
}
