#python  left and right >> <<shift operator tutorial
READ = 1 << 0    # 0001
WRITE = 1 << 1   # 0010
EXECUTE = 1 << 2 # 0100

permissions = READ | WRITE

print(permissions)          # 3
print(permissions & WRITE)  # 2 (WRITE is set)