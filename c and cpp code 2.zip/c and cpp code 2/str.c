#include<stdio.h>
#include<conio.h>
struct head{
	char Name[30];
	int age;
	int clas;
	int result;
	/* c language multiple structure tutorial*/
};
struct skk{
	char Name[30];
	int age;
	int clas;
	int result;
	/* c language multiple tutorial*/
};
struct pkk{
	char Name[30];
	int age;
	int clas;
	int result;
	/* c language multiple tutorial*/
};
int main(){
	struct head jk;
	struct skk js;
	struct pkk jt;
	printf("enter your Name: \n ");
	scanf("%s",&jk.Name);
	printf("enter your age: \n  ");
	scanf("%d",&jk.age);
	printf("enter your class:  \n ");
	scanf("%d",&jk.clas);
	printf("enter your result: \n  ");
	scanf("%d",&jk.result);
	printf(" your Name: %s \n ",jk.Name);
	printf(" your age :%d \n ",jk.age);
	printf("your class:%d \n ",jk.clas);
	printf(" your result:%d \n ",jk.result);
	printf("enter your Name: \n ");
	scanf("%s",&js.Name);
	printf("enter your age: \n  ");
	scanf("%d",&js.age);
	printf("enter your class:  \n ");
	scanf("%d",&js.clas);
	printf("enter your result: \n  ");
	scanf("%d",&js.result);
	printf(" your Name: %s \n ",js.Name);
	printf(" your age :%d \n ",js.age);
	printf("your class:%d \n ",js.clas);
	printf(" your result:%d \n ",js.result);
	printf("enter your Name: \n ");
	scanf("%s",&jt.Name);
	printf("enter your age: \n  ");
	scanf("%d",&jt.age);
	printf("enter your class:  \n ");
	scanf("%d",&jt.clas);
	printf("enter your result: \n  ");
	scanf("%d",&jt.result);
	printf(" your Name: %s \n ",jt.Name);
	printf(" your age :%d \n ",jt.age);
	printf("your class:%d \n ",jt.clas);
	printf(" your result:%d \n ",jt.result);

}
