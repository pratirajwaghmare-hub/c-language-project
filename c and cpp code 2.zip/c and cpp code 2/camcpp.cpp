#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;

int main() {
    // Open default webcam (0)
    VideoCapture camera(0);

    if (!camera.isOpened()) {
        cout << "Error: Camera open nahi hua!" << endl;
        return -1;
    }

    cout << "Camera started successfully!" << endl;
    cout << "Press ESC to exit." << endl;

    Mat frame;

    while (true) {
        camera >> frame;

        if (frame.empty()) {
            cout << "Empty frame received!" << endl;
            break;
        }

        imshow("C++ Camera", frame);

        if (waitKey(1) == 27) { // ESC key
            break;
        }
    }

    camera.release();
    destroyAllWindows();

    return 0;
}
