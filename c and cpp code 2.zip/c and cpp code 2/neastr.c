#include<stdio.h>
#include<conio.h>
struct hi{
	char name[40];
	int age;
	int clas;
	int marks;
	
	/* c lnaguage nested tutorial*/
};
struct ase{
	struct hi 
};
struct tech{
	/* c lnaguage multiple nested tutorial*/
	struct ase 
};
int main(){
	struct  tech  ks;
	printf("Enter your name");
	scanf("%s",&ks.name);
	printf("Enter your age");
	scanf("%d",&ks.age);
	printf("Enter your class");
	scanf("%d",&ks.clas);
	printf("Enter your marks");
	scanf("%d",&ks.marks);
	
	
	printf(" your name %s \n",ks.name);
	printf(" your age %d \n",ks.age);
	printf(" your age %d \n",ks.clas);
	printf(" your marks %d \n",ks.marks);
}
